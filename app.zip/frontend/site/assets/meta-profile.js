/* Meta Profile page - Vector Visualization
   - Rappresentazione 2D MDI (X) vs MPI (Y)
   - Visualizzazione a vettori (frecce dall'origine)
   - Quadranti tematici per definire lo stile di gioco
*/

(function () {
  "use strict";

  const SAT_LIMIT = 1.0; // Limite assi per simmetria
  const elMeta = document.getElementById("meta");
  const elPlayer = document.getElementById("fPlayer");
  const elMinGames = document.getElementById("fMinGames");
  const tBody = document.querySelector("#tCmd tbody");

  let profileChart = null;
  let stats = null;

  // Colori per i quadranti (molto tenui)
  const QUAD_COLORS = {
    topRight: "rgba(34, 197, 94, 0.05)", // Greenish
    topLeft: "rgba(239, 68, 68, 0.05)",  // Reddish
    bottomRight: "rgba(110, 231, 255, 0.05)", // Cyanish
    bottomLeft: "rgba(156, 163, 175, 0.05)"   // Greyish
  };

  // --- PLUGIN: QUADRANTI E FRECCE ---
  const vectorPlugin = {
    id: 'vectorPlugin',
    beforeDraw: (chart) => {
      const { ctx, chartArea: { top, bottom, left, right, width, height }, scales: { x, y } } = chart;
      const centerX = x.getPixelForValue(0);
      const centerY = y.getPixelForValue(0);

      // 1. Disegna Sfondi Quadranti
      ctx.save();
      // Top Right
      ctx.fillStyle = QUAD_COLORS.topRight;
      ctx.fillRect(centerX, top, right - centerX, centerY - top);
      // Top Left
      ctx.fillStyle = QUAD_COLORS.topLeft;
      ctx.fillRect(left, top, centerX - left, centerY - top);
      // Bottom Right
      ctx.fillStyle = QUAD_COLORS.bottomRight;
      ctx.fillRect(centerX, centerY, right - centerX, bottom - centerY);
      // Bottom Left
      ctx.fillStyle = QUAD_COLORS.bottomLeft;
      ctx.fillRect(left, centerY, centerX - left, bottom - centerY);

      // 2. Etichette Quadranti
      ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
      ctx.font = "bold 12px Inter, system-ui";
      ctx.textAlign = "center";
      ctx.fillText("PREDATOR", left + (centerX - left) / 2, top + 20);
      ctx.fillText("ELITE", centerX + (right - centerX) / 2, top + 20);
      ctx.fillText("CASUAL", left + (centerX - left) / 2, bottom - 15);
      ctx.fillText("UNDERDOG", centerX + (right - centerX) / 2, bottom - 15);
      ctx.restore();
    },
    afterDatasetsDraw: (chart) => {
      const { ctx, scales: { x, y } } = chart;
      const centerX = x.getPixelForValue(0);
      const centerY = y.getPixelForValue(0);

      chart.data.datasets.forEach((dataset, i) => {
        const meta = chart.getDatasetMeta(i);
        if (meta.hidden) return;

        meta.data.forEach((point, index) => {
          const raw = dataset.data[index];
          const targetX = point.x;
          const targetY = point.y;

          // Disegna la linea del vettore
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(centerX, centerY);
          ctx.lineTo(targetX, targetY);
          ctx.strokeStyle = point.options.borderColor;
          ctx.lineWidth = 2;
          ctx.globalAlpha = 0.6;
          ctx.setLineDash([5, 3]); // Linea tratteggiata per stile "vettore"
          ctx.stroke();

          // Disegna freccia alla fine (piccola punta prima del cerchio)
          const angle = Math.atan2(targetY - centerY, targetX - centerX);
          ctx.translate(targetX, targetY);
          ctx.rotate(angle);
          ctx.beginPath();
          ctx.moveTo(-10, -5);
          ctx.lineTo(0, 0);
          ctx.lineTo(-10, 5);
          ctx.stroke();
          ctx.restore();
        });
      });
    }
  };

  function getPlayerColor(name) {
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    const h = Math.abs(hash) % 360;
    return `hsl(${h}, 70%, 60%)`;
  }

  function renderVectorPlot(players) {
    const canvas = document.getElementById("profileChart");
    if (!canvas) return;
    if (profileChart) profileChart.destroy();

    const datasets = players.map(p => {
      const color = getPlayerColor(p.player);
      return {
        label: p.player,
        data: [{ x: p.mdi, y: p.mpi, r: Math.max(5, Math.sqrt(p.games) * 2) }],
        backgroundColor: color.replace("60%)", "60%, 0.4)"),
        borderColor: color,
        borderWidth: 2,
        hoverRadius: 10
      };
    });

    profileChart = new Chart(canvas.getContext("2d"), {
      type: 'bubble',
      data: { datasets },
      plugins: [vectorPlugin],
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            min: -SAT_LIMIT, max: SAT_LIMIT,
            title: { display: true, text: "Matchup Difficulty (MDI) ← Facile | Difficile →", color: "#aab3d3" },
            grid: { color: "rgba(255,255,255,0.1)", borderColor: "#fff" },
            ticks: { color: "#888" }
          },
          y: {
            min: -SAT_LIMIT, max: SAT_LIMIT,
            title: { display: true, text: "Meta Power (MPI) ← Bassa | Alta →", color: "#aab3d3" },
            grid: { color: "rgba(255,255,255,0.1)", borderColor: "#fff" },
            ticks: { color: "#888" }
          }
        },
        plugins: {
          legend: { position: 'right', labels: { color: "#e9ecf7", boxWidth: 12, usePointStyle: true } },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const p = ctx.dataset.label;
                return `${p}: MDI ${ctx.raw.x.toFixed(2)}, MPI ${ctx.raw.y.toFixed(2)}`;
              }
            }
          }
        }
      }
    });
  }

  function renderCommanderTable(player, minGames) {
    if (!tBody || !stats) return;
    tBody.innerHTML = "";
    const rows = (stats.meta_profile_by_player_commander || [])
      .filter(r => r.player === player && r.games >= minGames)
      .sort((a, b) => b.mpi - a.mpi);

    rows.forEach(r => {
      const tr = document.createElement("tr");

      // Colore riga basato su MPI
      const mpiVal = Math.max(-1, Math.min(1, r.mpi));
      const opacity = Math.abs(mpiVal) * 0.2;
      const colorBase = mpiVal >= 0 ? "34, 197, 94" : "239, 68, 68";
      tr.style.backgroundColor = `rgba(${colorBase}, ${opacity})`;

      tr.innerHTML = `
        <td style="font-weight:bold">${r.commander}</td>
        <td class="num">${r.games}</td>
        <td class="num" title="MDI: ${r.mdi.toFixed(2)}">${r.mdi.toFixed(2)}</td>
        <td class="num" style="font-weight:bold">${r.mpi.toFixed(2)}</td>
      `;
      tBody.appendChild(tr);
    });
  }

  async function init() {
    try {
      const res = await fetch("../data/stats.v1.json", { cache: "no-cache" });
      stats = await res.json();

      if (elMeta) elMeta.textContent = `Generato il: ${stats.generated_utc}`;

      const players = stats.filters.players || [];
      elPlayer.innerHTML = players.sort().map(p => `<option value="${p}">${p}</option>`).join("");

      // Render Plot
      renderVectorPlot(stats.meta_profile_by_player || []);

      // Render Table
      renderCommanderTable(elPlayer.value, Number(elMinGames.value));

      elPlayer.addEventListener("change", () => renderCommanderTable(elPlayer.value, Number(elMinGames.value)));
      elMinGames.addEventListener("change", () => renderCommanderTable(elPlayer.value, Number(elMinGames.value)));

    } catch (e) {
      console.error("Errore caricamento profilo:", e);
    }
  }

  window.addEventListener("DOMContentLoaded", init);
})();